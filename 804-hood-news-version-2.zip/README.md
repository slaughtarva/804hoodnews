# 804 Hood News Version 2

Custom Richmond-focused redesign using the official 804 Hood News logo.

## Upload to Netlify
Upload this ZIP through the Production Deploys drag-and-drop area.

## Included
- Custom homepage
- Official logo
- Mobile navigation
- Working page search
- Dark mode
- Breaking news ticker
- Article template
- Video section
- Ad placements
- Netlify newsletter, contact, advertising and tip forms

Weather shown is placeholder data until a live weather service is connected.
